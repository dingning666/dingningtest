package test;

import java.util.*;
import java.util.stream.Collectors;
import test.Student;

/**
 * 学生各种信息
 *
 * @author liyuxian
 * 2020-03-04 17：20
 */
public class StudentMap {
    public static void main(String[] args) {
        Map<Integer, Student> map1 = new HashMap<>();
        /**
         * 创建学生对象和赋值到Map集合
         */
        map1.put(1, new Student("张三", 18, 80, "1班"));
        map1.put(2, new Student("李四", 19, 100, "1班"));
        map1.put(3, new Student("王五", 17, 59, "1班"));

        Map<Integer, Student> map2 = new HashMap<>();
        map2.put(4, new Student("赵六", 18, 85, "2班"));
        map2.put(5, new Student("刘七", 19, 93, "2班"));
        map2.put(6, new Student("孙八", 17, 55, "2班"));



        System.out.println("-----------------------");
        System.out.println("1.整合两个map学生信息成一个新的map");
        /**
         * 合并map1和map2
         */
        map1.putAll(map2);
        /**
         * map1.keySet()获取key的值
         */
        for (Integer key : map1.keySet()) {
            System.out.println("编号是:" + key + "\t" + map1.get(key).getName() + "--" + map1.get(key).getAge()
                    + "--" + map1.get(key).getGrade() + "--" + map1.get(key).getClasses());
        }



        System.out.println("-----------------------");
        System.out.println("2.按照分数给出学生信息排名");
        /**
         * map排序
         */




        System.out.println("-----------------------");
        System.out.println("3.输出不及格的学生信息");
        /**
         * 判断成绩是否小于60，并输出
         */
        for (Integer key : map1.keySet()) {
            if (map1.get(key).getGrade() < 60) {
                System.out.println("编号是:" + key + "\t" + map1.get(key).getName() + "--" + map1.get(key).getAge()
                        + "--" + map1.get(key).getGrade() + "--" + map1.get(key).getClasses());
            }

        }




        System.out.println("-----------------------");
        System.out.println("4.查找张三的信息");
        /**
         *判断是否为张三，并输出
         */
        for (Integer key : map1.keySet()) {
            if (map1.get(key).getName().equals("张三")) {
                System.out.println("编号是:" + key + "\t" + map1.get(key).getName() + "--" + map1.get(key).getAge()
                        + "--" + map1.get(key).getGrade() + "--" + map1.get(key).getClasses());
            }

        }




        System.out.println("-----------------------");
        System.out.println("5.从map剔除年龄大于18岁的学生信息");
        /**
         * 判断年龄是否不并输出
         */

        for (Integer key : map1.keySet()) {
            if (map1.get(key).getAge() <= 18) {
                System.out.println("编号是:" + key + "\t" + map1.get(key).getName() + "--" + map1.get(key).getAge()
                        + "--" + map1.get(key).getGrade() + "--" + map1.get(key).getClasses());
            }

        }


    }
}
