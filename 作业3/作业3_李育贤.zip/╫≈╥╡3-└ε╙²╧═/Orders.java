package test;
/**
 * 订单实体类
 *
 * @author liyuxian
 * 2020-03-04 17：19
 */
public class Orders {
    /**
     * 订单编号
     */
    private String Number;
    /**
     * 创建时间
     */
    private  String  createTime;
    /**
     * 付款时间
     */
    private  String  parmentTime;
    /**
     * 发货时间
     */
    private String deliveryTime;
    /**
     * 积分
     */
    private String intergal;
    /**
     * 订单价格
     */
    private String price;

    public String getNumber() {
        return Number;
    }

    public void setNumber(String number) {
        Number = number;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getParmentTime() {
        return parmentTime;
    }

    public void setParmentTime(String parmentTime) {
        this.parmentTime = parmentTime;
    }

    public String getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(String deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public String getIntergal() {
        return intergal;
    }

    public void setIntergal(String intergal) {
        this.intergal = intergal;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
