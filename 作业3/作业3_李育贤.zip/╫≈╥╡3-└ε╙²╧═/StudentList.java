package test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 学生各种信息
 *
 * @author liyuxian
 * 2020-03-04 17：20
 */
public class StudentList {
    public static void main(String[] args) {

        List<Student> list1 = new ArrayList<>();
        /**
         * 创建学生对象并赋值到List集合
         */
        list1.add(new Student("张三", 18, 80, "1班"));
        list1.add(new Student("李四", 19, 100, "1班"));
        list1.add(new Student("王五", 17, 59, "1班"));

        List<Student> list2 = new ArrayList<>();
        list2.add(new Student("赵六", 18, 85, "2班"));
        list2.add(new Student("刘七", 19, 93, "2班"));
        list2.add(new Student("孙八", 17, 55, "2班"));


        System.out.println("-----------------------");
        System.out.println("1.整合两个list学生信息成一个新的list");
        /**
         * 合并list1和list2
         */
        list1.addAll(list2);

        for (int i = 0; i < list1.size(); i++) {

            System.out.println(list1.get(i));

        }


        System.out.println("-----------------------");
        System.out.println("2.按照分数给出学生信息排名");
        /**
         * sort排序
         */
        list1.sort(new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                Integer i1 = o1.getGrade();
                Integer i2 = o2.getGrade();
                return i1.compareTo(i2);
            }
        });
        for (int i = 0; i < list1.size(); i++) {

            System.out.println(list1.get(i));

        }


        System.out.println("-----------------------");
        System.out.println("3.输出不及格的学生信息");
        for (int i = 0; i < list1.size()-1; i++) {

            if (list1.get(i).getGrade() < 60) {
                System.out.println(list1.get(i));
            }

        }


        System.out.println("-----------------------");
        System.out.println("4.查找张三的信息");
        for (int i = 0; i < list1.size(); i++) {

            if (list1.get(i).getName().equals("张三")) {
                System.out.println(list1.get(i));
            }

        }

        System.out.println("-----------------------");
        System.out.println("5.从list剔除年龄大于18岁的学生信息");
        /**
         *使用break跳出循环，是因为list删除后会size减1
         */
        for (int i = 0; i < list1.size(); i++) {

            if (list1.get(i).getAge()>18) {
                list1.remove(i);
                break;
            }
            System.out.println(list1.get(i));
        }



    }
}
