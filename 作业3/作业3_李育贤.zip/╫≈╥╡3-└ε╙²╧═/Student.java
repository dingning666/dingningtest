package test;

/**
 * 学生实体类
 *
 * @author liyuxian
 * 2020-03-04 17：19
 */
public class Student {
    /**
     * 姓名
     */
    private String name;
    /**
     * 年龄
     */
    private int age;
    /**
     * 成绩
     */
    private int grade;
    /**
     * 班级
     */
    private String classes;

    public Student(String name, int age, int grade, String classes) {
        this.name = name;
        this.age = age;
        this.grade = grade;
        this.classes = classes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String getClasses() {
        return classes;
    }

    public void setClasses(String classes) {
        this.classes = classes;
    }

    /**
     * 重写toString 方法
     * @return
     */
    @Override
    public String toString(){
        return getName()+ "--" + getAge() + "--" + getGrade() + "--" + getClasses();
    }

}